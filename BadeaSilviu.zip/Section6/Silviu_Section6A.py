import subprocess
import time
import os
import gzip
from datetime import datetime

LOG_FILE = "/var/log/sys_health.log" #Path where the live log will be written
ARCHIVE_DIR = "/var/log/sys_health_archives" #Directory where hourly archived logs will be stored 

#Creates the log file and directory 
def setup_logging():
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w") as f:
            f.write("Sys Health\n")
    if not os.path.exists(ARCHIVE_DIR):
        os.makedirs(ARCHIVE_DIR)

def get_cpu_usage():
    result = subprocess.run(["top", "-bn1"], capture_output = True, text = True) #Get CPU usage by running "top"
    for line in result.stdout.splitlines():
        if "Cpu(s)" in line:
            return line.strip()

def get_ram_usage():
    result = subprocess.run(["free", "-h"], capture_output = True, text = True) #Get RAM usage by running "free -h"
    return result.stdout.strip()

def get_disk_usage():
    result = subprocess.run(["df", "-h", "/"], capture_output = True, text = True) #Get disk usage info for the root filesystem using "df -h /"
    return result.stdout.strip()

def get_top_processes():
    result = subprocess.run(["ps", "-eo", "pid,comm,%mem", "--sort=-%mem"], capture_output = True, text = True)
    lines = result.stdout.strip().splitlines()
    return "/n".join(lines[:6])

#Writes the system health information into the log file
def log_system_health():
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a") as f:
        f.write(f"Sys Health Log ({now}) \n")
        f.write("CPU USAGE: " + get_cpu_usage() + "\n")
        f.write("RAM USAGE: " + get_ram_usage() + "\n")
        f.write("DISK USAGE: " + get_disk_usage() + "\n")
        f.write("Top 5 processes: " + get_top_processes() + "\n")

def archive_log():
    timestamp = datetime.now().strfime("%Y%m%d_%H%M") #Create a filename with a timestamp
    archive_path = os.path.join(ARCHIVE_DIR, f"sys_health_{timestamp}.log.gz")
    with open(LOG_FILE, 'rb') as f_in, gzip.open(archive_path, 'wb') as f_out: #Compress the existing log file
        f_out.write(f_in.read())
    open(LOG_FILE, "w").close() #Clear the log file to start fresh every hour

def main():
    print("Starting....")
    setup_logging() 
    print("Setting up...")
    last_hour = datetime.now().hour
    while True:
        log_system_health() #Write the current system health
        time.sleep(300) 
        current_hour = datetime.now().hour
        if current_hour != last_hour:
            archive_log() #Archive log once per hour
            last_hour = current_hour

if __name__ == "__main__":
	main()
