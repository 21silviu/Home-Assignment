#!/bin/bash

#Make sure group is present
if ! getent group iotusers > /dev/null; then
	sudo groupadd iotusers
	echo "Group iotusers created"
else
	echo "Group iotusers already exists"
fi

#Add users
for user in iotuser1 iotuser2; do
	if ! id "$user" %>/dev/null; then
		sudo useradd -m -G iotusers "$user"
		echo "User $user created and added to iotusers"
	else
		echo "User $user already exists"
		sudo usermod -a -G iotusers "$user" #Add user to group if it's not in the group
	fi
done

#Create shared directory
if [ ! -d /home/iotshared ]; then
	sudo mkdir /home/iotshared
	echo "Directory /home/iotshared created"
else
	echo "Directory /home/iotshared already exists"
fi

#Set ownership and permissions
sudo chown root:iotusers /home/iotshared
sudo chmod 2775 /home/iotshared
