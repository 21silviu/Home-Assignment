import csv
import statistics

times = []
temps = []
humid = []
with open('sensor_data.csv') as f:
    r = csv.reader(f)
    next(r)
    for row in r:
        times.append(row[0])
        temps.append(float(row[1]))
        humid.append(float(row[2]))

def filter_mad(vals, thresh=3.5):
    median = statistics.median(vals)
    abs_devs = [abs(v - median) for v in vals]
    mad = statistics.median(abs_devs)
    res = []
    for v in vals:
        if mad == 0:
            res.append(v)
        else:
            mod_z = 0.6745 * (v - median) / mad
            if abs(mod_z) < thresh:
                res.append(v)
            else:
                res.append(None)
    return res

clean_temps = filter_mad(temps)
clean_humid = filter_mad(humid)

def find_trend(lst):
    vals = [v for v in lst if v is not None]
    if len(vals) < 2:
        return 'No trend'
    if vals[-1] > vals[0]:
        return 'Increasing'
    if vals[-1] < vals[0]:
        return 'Decreasing'
    else:
        return 'No trend'

with open('sensor_data_cleaned.csv','w',newline='') as f:
    w = csv.writer(f)
    w.writerow(['time','temperature_clean','humidity_clean'])
    for t, temp, humid in zip(times, clean_temps, clean_humid):
        w.writerow([t, '' if temp is None else temp, '' if humid is None else humid])

with open('sensor_report.txt', 'w') as f:
    f.write('Temperature trend: ' + find_trend(clean_temps) + '\n')
    f.write('Humidity trend: ' + find_trend(clean_humid) + '\n')
    f.write('Points kept (temp): ' + str(sum(1 for v in clean_temps if v is not None)) + '\n')
    f.write('Points kept (humid): ' + str(sum(1 for v in clean_humid if v is not None)) + '\n')
    temp_vals = [v for v in clean_temps if v is not None]
    humid_vals = [v for v in clean_humid if v is not None]
    f.write('Temp avg: {:.2f}\n'.format(statistics.mean(temp_vals)))
    f.write('Temp min: {:.2f}\n'.format(min(temp_vals)))
    f.write('Temp max: {:.2f}\n'.format(max(temp_vals)))
    f.write('Hum avg: {:.2f}\n'.format(statistics.mean(humid_vals)))
    f.write('Hum min: {:.2f}\n'.format(min(humid_vals)))
    f.write('Hum max: {:.2f}\n'.format(max(humid_vals)))

print('Done')